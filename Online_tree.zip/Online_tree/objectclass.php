<?php
	class user{
		
		private $db_connect;
		public function __construct() {
		$host = 'localhost';
		$user = 'root';
		$password = '';
		$database = 'online_tree';
		$this->db_connect = mysqli_connect($host, $user, $password, $database);
		if (!$this->db_connect) {
			die("Connection Fail".mysqli_error($this->db_connect));
			}
		}
						
		public function register_user($user){
			$sql = "SELECT * FROM login_reg";
			$query = mysqli_query($this->db_connect, $sql);
			$rows = mysqli_num_rows($query);
			
			if($rows == 1){
				$message = "User Already Exist";
				return $message;
			}
			else {
				$pass = md5($user['password']);
				$sql = "INSERT INTO login_reg (email,password) VALUES('$user[email]','$pass')";
				$query = mysqli_query($this->db_connect, $sql);
					if($query){
						$message = "Registration Sucessfully";
						return $message;
					}
			}
					
		
		
		}			
		public function check_login($user){
        $email = $user['email'];
        $password = md5($user['password']);
              
        $sql = "SELECT * FROM  login_reg WHERE email='$email' AND password='$password'";
        
        if (mysqli_query($this->db_connect, $sql)) {
            $query = mysqli_query($this->db_connect, $sql);
            $user_info = mysqli_fetch_assoc($query);
            if ($user_info) {
					session_start();
                    $_SESSION['id'] = $user_info['id'];			
                    header('location: user/my-account.php');
            }
            else {
                $message = "You have entered wrong email or password";
                return $message;
            }
        }
         
      }        
       public function logout(){ 
	     unset($_SESSION['id']);       
         header("location:../login-register.php");
       }
		
		
		
		
		
		
	}// Class End




?>