<?php include 'inc/header.php'; ?>			
			<!-- start: Content -->
	<div id="content" class="span12">	
<?php 
	if(isset($_POST['submit'])){
		$message = $obj->add_catagory($_POST);
	}	
?>
		 <ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Catagory</a></li>
			</ul>
			
			<div class="col-md-12">
			<h1> <?php if(isset($message)){echo $message;}?> </h1>
			<form class="form-horizontal" action="" method="post">
			 <fieldset>
			   <div class="control-group">						  
					<label class="control-label" for="typeahead">Add Product Category </label><br><br>	  
					<input type="text" name="cat_name" required /><br><br>
                    <input type="submit" name="submit" value="Add Catagory" />					
			   </div>
			 </fieldset>  
            </form>			 
	       </div>
    </div>
	
<?php include 'inc/footer.php'; ?>	