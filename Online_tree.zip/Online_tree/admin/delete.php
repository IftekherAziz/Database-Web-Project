<?php include 'inc/header.php'; 
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$message = $obj->delete_product_info($id);
		return $message;
	}
	

	 
?>			
		 	
<?php include 'inc/footer.php'; ?>	