<?php include 'inc/header.php';
	$query = $obj->select_all_catagory();
 ?>
						
	<div id="content" class="span12">	
		 <ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">All Category</a></li>
		</ul>			
		<div class="col-md-12">
			<div class="box-content">
			    <table class="table  table-responsive">
				   <thead>							
							<tr>
								  
								  <th>Category No</th>
								  <th>Category Name</th>
							</tr>							
				    </thead> 
                    <tbody>
                    	<?php while($row = mysqli_fetch_assoc($query)){?>
						<tr>
                    		
							<td><?php echo $row['cat_id'];?></td>
							
							<td><?php echo $row['cat_name'];?></td>
                    	</tr>
						<?php }?>
                    </tbody>
                </table>					
	       </div>
    </div>
	
<?php include 'inc/footer.php'; ?>	