﻿<?php include 'inc/header.php'; ?>
			<!-- start: Content -->
			<div id="content" class="span12">			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">All User</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">					
					<div class="box-content">
						<table class="table  table-responsive table-hover table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Username</th>
								  <th>Date registered</th>
								  <th>Role</th>
								  <th>Status</th>
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
							<tr>
								<td>Eftekher Aziz</td>
								<td class="center">2018/07/15</td>
								<td class="center">Admin</td>
								<td class="center">							    
									<span class="label label-important">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white zoom-in"></i>view
									</a>
									
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
							<tr>
								<td>Eftekher Aziz</td>
								<td class="center">2018/07/15</td>
								<td class="center">Member</td>
								<td class="center">
									<span class="label label-success">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white zoom-in"></i>view
									</a>
									
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
							<tr>
								<td>Eftekher Aziz</td>
								<td class="center">2018/07/15</td>
								<td class="center">Member</td>
								<td class="center">
									<span class="label label-success">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white zoom-in"></i>view
									</a>
									
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>							
							</tr>
							<tr>
								<td>Eftekher Aziz</td>
								<td class="center">2018/07/15</td>
								<td class="center">Member</td>
								<td class="center">
									<span class="label label-success">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white zoom-in"></i>view
									</a>
									
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
							<tr>
								<td>Eftekher Aziz</td>
								<td class="center">2018/07/15</td>
								<td class="center">Member</td>
								<td class="center">
									<span class="label label-success">Active</span>
								</td>
								<td class="center">
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white zoom-in"></i>view
									</a>
									
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>																										
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->	
               </div>				
			</div><!--/row-->
			
<?php include 'inc/footer.php'; ?>