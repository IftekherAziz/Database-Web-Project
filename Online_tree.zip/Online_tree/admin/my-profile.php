<?php include 'inc/header.php'; ?>			
			<!-- start: Content -->
	<div id="content" class="span12">				
		<ul class="breadcrumb">
			<li>
			   <i class="icon-home"></i>
			   <a href="superadmin.php">Home</a> 
			   <i class="icon-angle-right"></i>
			</li>
			<li><a href="#">My Profile</a></li>
		</ul>	
    </div>
	
<?php include 'inc/footer.php'; ?>	