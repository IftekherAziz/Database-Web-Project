<?php include 'inc/header.php';
    
 ?>	
			<!-- start: Content -->
		<div id="content" class="span12">
<?php if(isset($_POST['submit'])){
		
		$message = $obj->add_product($_POST);
	}	
?>		
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Add New Product</a></li>
			</ul>
						
			<div class="col-md-12">
			   <h1> <?php if(isset($message)){echo $message;}?> </h1>
			   <div class="box-content">
				 <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
						  <fieldset>
							<div class="control-group">
							  <label  class="control-label" for="typeahead">Product Name </label>
                               <span style="margin-left:20px;"><input type="text" name="p_name" required /></span><br><br>				  
							  <label class="control-label" for="typeahead">Product Price </label>	  
							   <span style="margin-left:20px;"><input type="text" name="p_price" required /></span><br><br>  
							   <label class="control-label" for="typeahead">Product Category </label>	  
							   <span style="margin-left:20px;"><input type="text" name="cat_name" required /></span><br>	  
							</div>			
							<div class="control-group">
							  <label class="control-label" for="fileInput">Product Image</label>
							  <div class="controls">
								<input class="input-file uniform_on" id="fileInput" name="p_photo" type="file" required />
							  </div>
							</div>          
							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Product Description</label>
							  <div class="controls">		   
                                <textarea name="p_description" class="cleditor" id="textarea2" cols="30" rows="10" required> </textarea>								
							  </div>
							</div>
							<div class="form-actions">
							  <input type="submit"  name="submit" class="btn btn-primary" value="Add Product" />			 
							</div>
						  </fieldset>
						</form>   		
			   </div>
            </div>
		</div>	
		 
<?php include 'inc/footer.php'; ?>	