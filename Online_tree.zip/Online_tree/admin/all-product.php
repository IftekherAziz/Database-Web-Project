<?php include 'inc/header.php'; 
 
 $query = $obj->select_all_product();

?>			
			<!-- start: Content -->
			<div id="content" class="span12">				
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">All Product</a></li>
			</ul>
			
			<div class="col-md-12">
			 <div class="table-responsive">
				<table class="table table-bordered">
                    <thead>
                      <tr>
                        <th style="text-align:center;" >Name</th>                       
                        <th style="text-align:center;" >Price</th> 
						<th style="text-align:center;" >Category</th>			
						<th style="text-align:center;" >Image</th>
						<th style="text-align:center;" >Details</th>
						<th style="text-align:center;" >Action</th>	
                     </tr>
                   </thead>
                   <tbody>
				     <?php while($row = mysqli_fetch_assoc($query)){?>
						<tr>                   		
							<td><?php echo $row['p_name'];?></td>
							<td><?php echo $row['p_price'];?></td>
							<td><?php echo $row['cat_name'];?></td>							
							<td style="height:100px;width:100px;"><img src="<?php echo $row['p_photo'];?>" alt="" /></td>
							<td><?php echo $row['p_description'];?></td>
							<td>
							  <a style="text-decoration:none;" href="edit.php?id=<?php echo $row['id'];?>"><button > Edit</button></a><br><br>
							  <a onclick="return check_delete();" style="text-decoration:none;" href="delete.php?id=<?php echo $row['id'];?>"><button> Delete</button</a>
  					        </td>
                    	</tr>
						<?php }?>                    					 
                  </tbody>
             </table>
		   </div>
	     </div>
    </div>
	
<?php include 'inc/footer.php'; ?>	