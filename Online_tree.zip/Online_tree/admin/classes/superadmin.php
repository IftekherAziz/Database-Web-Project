<?php 
class admin{
    private $db_connect;
    public function __construct() {
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'online_tree';
    $this->db_connect = mysqli_connect($host, $user, $password, $database);
    if (!$this->db_connect) {
    die("Connection Fail".mysqli_error($this->db_connect));
        }
    }
    
    public function admin_login_check($data){
        $email_address = $data['username'];
        $password = md5($data['password']);
        
        
        
        $sql = "SELECT * FROM admin_login WHERE username='$email_address' AND password='$password'";
        
        if (mysqli_query($this->db_connect, $sql)) {
            $query_result = mysqli_query($this->db_connect, $sql);
            $admin_info = mysqli_fetch_assoc($query_result);
            if ($admin_info) {
                session_start();
                $_SESSION['admin_name'] = $admin_info['admin_name'];
                $_SESSION['admin_id'] = $admin_info['admin_id'];
                
                header("location: superadmin.php");
            }
            else {
                $message = "You have entered Wrong Email or Password";
                return $message;
            }
        }
         
    }        
    public function admin_logout(){ 
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_id']);
        header("location: index.php");
    }
    
    public function add_catagory($data){
		
		$sql = "INSERT INTO catagory (cat_name) VALUES('$data[cat_name]')";
		$query = mysqli_query($this->db_connect, $sql);
		if($query){
			$message = "Catagory Added Sucessfully";
			return $message;
		}
		
	}
    public function select_all_catagory(){
		$sql = "SELECT * FROM catagory";
		$query = mysqli_query($this->db_connect, $sql);
		return $query;
	}
	public function add_product($addproduct){
		
		$directory = '../image/';
        $target_file = $directory.$_FILES['p_photo']['name'];
        $filetype = pathinfo($target_file, PATHINFO_EXTENSION);
        $filesize = $_FILES['p_photo']['size'];
        $image = getimagesize($_FILES['p_photo']['tmp_name']);
        if($image){
            if(file_exists($target_file)){
				$message = "File Already Exists";
                return $message;
            }
            else {
                if($filesize>5242880){
					$message = "File To Large";
					return $message;
                }
                else{
                    if ($filetype != 'jpg' && $filetype != 'png') {
                        $message = "File Type Not Valid. Please Upload PNG OR JPG";
						return $message;
                    }
                    else{
                        
                        $sql = "INSERT INTO add_product (p_name,p_price,cat_name,p_photo,p_description) VALUES('$addproduct[p_name]','$addproduct[p_price]','$addproduct[cat_name]','$target_file','$addproduct[p_description]')";
                        if(mysqli_query($this->db_connect, $sql)){
                            move_uploaded_file($_FILES['p_photo']['tmp_name'], $target_file);
                            $message = "Product Added Sucessfully";
                            return $message;
                        }
                        else{
                            die("Query Error".mysqli_error($this->db_connect));
                        }
                        
                    }
                }
            }
        }						
	}//Add product end
	
	//view all product
	public function select_all_product(){
		$sql = "SELECT * FROM add_product";
		$query = mysqli_query($this->db_connect, $sql);
		return $query;
	}
	

    // Update Product

    
    public function update_product($data){
        
        $directory = '../image/';
        $target_file = $directory.$_FILES['p_photo']['name'];
        $filetype = pathinfo($target_file, PATHINFO_EXTENSION);
        $filesize = $_FILES['p_photo']['size'];
        $image = getimagesize($_FILES['p_photo']['tmp_name']);
        if($image){
            if(file_exists($target_file)){
                $message = "File Already Exists";
                return $message;
            }
            else {
                if($filesize>5242880){
                    $message = "File To Large";
                    return $message;
                }
                else{
                    if ($filetype != 'jpg' && $filetype != 'png') {
                        $message = "File Type Not Valid. Please Upload PNG OR JPG";
                        return $message;
                    }
                    else{
                        
                        $sql = "UPDATE add_product SET p_name='$data[p_name]',p_price='$data[p_price]',cat_name='$data[cat_name]',p_photo='$target_file',p_description='$data[p_description]' WHERE id='$data[id]'";

                        if(mysqli_query($this->db_connect, $sql)){
                            move_uploaded_file($_FILES['p_photo']['tmp_name'], $target_file);
                            $message = "Product Updated Sucessfully";
                            return $message;
                        }
                        else{
                            die("Query Error".mysqli_error($this->db_connect));
                        }
                        
                    }
                }
            }
        }                       
    }//Update product end

    public function select_product_id($data){
        $sql = "SELECT * FROM add_product WHERE id='$data'";
        $query = mysqli_query($this->db_connect, $sql);
        $result = mysqli_fetch_assoc($query);
        return $result;

    }

    // Delete ID 

    public function delete_product_info($product_id) {
        $sql="DELETE FROM add_product WHERE id='$product_id'" ;
        if (mysqli_query($this->db_connect, $sql)) {
            header('location: all-product.php');
            
            
        }
        else {
            die("Query Error".mysqli_error($this->db_connect));
        }
    }
    
}