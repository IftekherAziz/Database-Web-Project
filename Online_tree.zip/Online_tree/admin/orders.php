<?php include 'inc/header.php'; ?>
			<!-- start: Content -->
			<div id="content" class="span12">			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">All User</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">					
					<div class="box-content">
						<table class="table  table-responsive table-hover table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th style="text-align:center;">#</th>
								  <th style="text-align:center;">Product Name</th>
								  <th style="text-align:center;">Product Id</th>
								  <th style="text-align:center;">Order Date</th>
								  <th style="text-align:center;">Price</th>
								  <th style="text-align:center;">Quantity</th>
								  <th style="text-align:center;">Status</th>
								  <th style="text-align:center;">Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
							<tr>
							    <td style="text-align:center;">1</td>
								<td style="text-align:center;">Mango Tree</td>
								<td style="text-align:center;">101</td>
								<td style="text-align:center;">2018/07/15</td>
								<td style="text-align:center;">10.99$</td>
								<td style="text-align:center;">2</td>			
								<td style="text-align:center;">							    
									<span class="label label-success">Processing</span>									
								</td>
								<td style="text-align:center;">
									
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white "></i>Send
									</a>
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
							<tr>
							    <td style="text-align:center;">2</td>
								<td style="text-align:center;">Rose Tree</td>
								<td style="text-align:center;">109</td>
								<td style="text-align:center;">2018/07/20</td>
								<td style="text-align:center;">05.99$</td>
								<td style="text-align:center;">5</td>			
								<td style="text-align:center;">							    
									<span class="label label-success">Processing</span>									
								</td>
								<td style="text-align:center;">
									
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white "></i>Send
									</a>
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
							<tr>
							    <td style="text-align:center;">3</td>
								<td style="text-align:center;">Mango Tree</td>
								<td style="text-align:center;">203</td>
								<td style="text-align:center;">2018/08/01</td>
								<td style="text-align:center;">8.00$</td>
								<td style="text-align:center;">5</td>			
								<td style="text-align:center;">							    
									<span class="label label-success">Processing</span>									
								</td>
								<td style="text-align:center;">
									
									<a class="btn btn-success" href="#">
										<i class="halflings-icon white "></i>Send
									</a>
									<a class="btn btn-danger" href="#">
										<i class="halflings-icon white trash"></i>Delete 
									</a>
								</td>
							</tr>
																													
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->	
               </div>				
			</div><!--/row-->
			
<?php include 'inc/footer.php'; ?>