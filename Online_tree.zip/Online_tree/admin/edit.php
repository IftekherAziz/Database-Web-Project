<?php include 'inc/header.php'; 
	
	if(isset($_GET['id'])){
		$product_id = $_GET['id'];
		$result = $obj->select_product_id($product_id);
	}
	

	 if(isset($_POST['update'])){
		
		$message = $obj->update_product($_POST);
		 header('location: all-product.php');
	}	

?>			
			<!-- start: Content -->
			<div id="content" class="span12">	

		
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Edit Product</a></li>
			</ul>
			<div class="col-md-12">
			   <h1> <?php if(isset($message)){echo $message;}?> </h1>
			   <div class="box-content">
				 <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
						  <fieldset>
							<div class="control-group">
							  <label  class="control-label" for="typeahead">Product Name </label>
                               <span style="margin-left:20px;">
                               	<input value="<?php echo $result['id'];?>" type="hidden" name="id" required />
                               	<input value="<?php echo $result['p_name'];?>" type="text" name="p_name" required /></span><br><br>				  
							  <label class="control-label" for="typeahead">Product Price </label>	  
							   <span style="margin-left:20px;">
							   	<input value="<?php echo $result['p_price'];?>" type="text" name="p_price" required /></span><br><br>  
							   <label class="control-label" for="typeahead">Product Category </label>	  
							   <span style="margin-left:20px;">
							   	<input value="<?php echo $result['cat_name'];?>" type="text" name="cat_name" required /></span><br>	  
							</div>			
							<div class="control-group">
							  <label class="control-label" for="fileInput">Product Image</label>

							  <div class="controls">
							  	
								<input  class="input-file uniform_on" id="fileInput" name="p_photo" type="file"  />
							  </div>
							</div>          
							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Product Description</label>
							  <div class="controls">		   
                                <textarea name="p_description" class="cleditor" id="textarea2" cols="30" rows="10" required> <?php echo $result['p_description'];?> </textarea>								
							  </div>
							</div>
							<div class="form-actions">
							  <input type="submit"  name="update" class="btn btn-primary" value="Update Product" />			 
							</div>
						  </fieldset>
						</form>   		
			   </div>
            </div>
		 
          </div>
		 	
<?php include 'inc/footer.php'; ?>	