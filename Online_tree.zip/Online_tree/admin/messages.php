﻿<?php include 'inc/header.php'; ?>			
			<!-- start: Content -->
			<div id="content" class="span12">				
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="superadmin.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Messages</a></li>
			</ul>
			
			<div class="col-md-12">
			 <div class="table-responsive">
				<table class="table table-hover table-bordered">
                    <thead>
                      <tr>
                       
                        <th>Name</th>
                        <th>Email</th> 
						<th>Subject</th> 
						<th>Details</th>
                     </tr>
                   </thead>
                   <tbody>
                      <tr>
                        <td>John Doe</td>                        
                        <td>john@example.com</td>
						<td>Return</td>
						<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et arcu vitae urna volutpat ornare accumsan vel arcu. Curabitur viverra felis metus, eget consectetur nisi rhoncus sed. Ut quis iaculis lectus. Curabitur sit amet purus eget dui mattis rutrum. Donec ut lectus in velit molestie auctor eu quis velit. Sed velit lorem, aliquam sed venenatis eu, semper vel nulla.</td>
                     </tr>
                     <tr>
                       <td>Mary Moe</td>                      
                       <td>hridoy@gmail.com</td>
					   <td>Return</td>
					   <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et arcu vitae urna volutpat ornare accumsan vel arcu. Curabitur viverra felis metus, eget consectetur nisi rhoncus sed. Ut quis iaculis lectus. Curabitur sit amet purus eget dui mattis rutrum. Donec ut lectus in velit molestie auctor eu quis velit. Sed velit lorem, aliquam sed venenatis eu, semper vel nulla.</td>                
                     </tr>
                     <tr>
                       <td>July Dooley</td>                      
                      <td>aziz@gmail.com</td>
					  <td>Return </td>
					  <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et arcu vitae urna volutpat ornare accumsan vel arcu. Curabitur viverra felis metus, eget consectetur nisi rhoncus sed. Ut quis iaculis lectus. Curabitur sit amet purus eget dui mattis rutrum. Donec ut lectus in velit molestie auctor eu quis velit. Sed velit lorem, aliquam sed venenatis eu, semper vel nulla.</td>                 
                    </tr>
                </tbody>
             </table>
		   </div>
	     </div>
    </div>
	
<?php include 'inc/footer.php'; ?>	