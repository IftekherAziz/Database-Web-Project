<?php
	ob_start();
	require 'classes/superadmin.php';
	$obj = new admin();
	if(isset($_GET['status'])){
		if($_GET['status']= 'logout'){
			$obj->admin_logout();
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Admin Panel</title>
	<meta name="description" content="">
	<meta name="author" content="Aziz Chy">
	<meta name="keyword" content=" ">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link id="bootstrap-style" href="css\bootstrap.min.css" rel="stylesheet">
	<link href="css\bootstrap-responsive.min.css" rel="stylesheet">
	<link id="base-style" href="css\style.css" rel="stylesheet">
	<link id="base-style-responsive" href="css\style-responsive.css" rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!-- end: CSS -->
	

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
		
	<!-- start: Favicon -->
	<link rel="shortcut icon" href="img/favicon.ico">
	<!-- end: Favicon -->
	
		<script>
            function check_delete() {
                var chk=confirm('Are you sure to delete this ?');
                if(chk) {
                    return true;
                } else {
                    return false;
                }
            }
        </script>
		
		
</head>

<body>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="superadmin.php"><span><b>Tree House </b></span></a>
								
				<!-- start: Header Menu -->
				<div class="nav-no-collapse header-nav">
					<ul class="nav pull-right">										
						<!-- start: User Dropdown -->
						<li class="dropdown">
							<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="halflings-icon white user"></i> Aziz Chy
								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<li class="dropdown-menu-title">
 									<span>Account Settings</span>
								</li>
								<li><a href="my-profile.php"><i class="halflings-icon user"></i> Profile</a></li>
								<li><a href="?status=logout"><i class="halflings-icon off"></i> Logout</a></li>
							</ul>
						</li>
						<!-- end: User Dropdown -->
					</ul>
				</div>
				<!-- end: Header Menu -->
				
			</div>
		</div>
	</div>	
	<!-- start: Header -->
	
		<div class="container-fluid-full">
		<div class="row-fluid">
				
			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li><a href="superadmin.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>	
						<li><a href="messages.php"><i class="icon-envelope"></i><span class="hidden-tablet"> Messages</span></a></li>						
						<li><a href="all-user.php"><i class="icon-lock"></i><span class="hidden-tablet"> All User</span></a></li>
						<li><a href="all-product.php"><i class="icon-lock"></i><span class="hidden-tablet">All Product</span></a></li>				
						<li><a href="add-product.php"><i class="icon-lock"></i><span class="hidden-tablet"> Add New Product</span></a></li>
						<li><a href="orders.php"><i class="icon-lock"></i><span class="hidden-tablet"> All Orders </span></a></li>
						<li><a href="category.php"><i class="icon-lock"></i><span class="hidden-tablet"> Add Category</span></a></li>
						<li><a href="allcategory.php"><i class="icon-lock"></i><span class="hidden-tablet"> All Category</span></a></li>
						<li><a href="my-profile.php"><i class="icon-lock"></i><span class="hidden-tablet"> My Profile </span></a></li>
						<li><a href="../index.php" target="_blank" ><i class="icon-lock"></i><span class="hidden-tablet"> Visit Website</span></a></li>
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>