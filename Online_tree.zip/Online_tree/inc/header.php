<?php 
	ob_start();
	include 'objectclass.php';
	$userobj = new user();
	
	session_start();
	
	
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Online Tree Shop</title>
	<meta name="description" content="">
	<meta name="robots" content="noindex, follow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, follow">
	<!-- Place favicon.ico in the root directory -->
	<link rel="shortcut icon" type="image/x-icon" href="img\favicon.ico">
    <!--All Css Here-->
    
    <!-- Bootstrap CSS-->
	<link rel="stylesheet" href="css\bootstrap.min.css">
	<!-- Linearicon CSS-->
    <link rel="stylesheet" href="css\linearicons.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css\font-awesome.min.css">

	<!-- Animate CSS-->
	<link rel="stylesheet" href="css\animate.css">
	<!-- Owl Carousel CSS-->
	<link rel="stylesheet" href="css\owl.carousel.min.css">
	<!-- Slick CSS-->
	<link rel="stylesheet" href="css\slick.css">
	<!-- Meanmenu CSS-->
	<link rel="stylesheet" href="css\meanmenu.min.css">
	<!-- Easyzoom CSS-->
	<link rel="stylesheet" href="css\easyzoom.css">
	<!-- Venobox CSS-->
	<link rel="stylesheet" href="css\venobox.css">
	<!-- Jquery Ui CSS-->
	<link rel="stylesheet" href="css\jquery-ui.css">
	<!-- Nice Select CSS-->
	<link rel="stylesheet" href="css\nice-select.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="css\responsive.css">
	<!-- Modernizr Js -->
	<script src="js\vendor\modernizr-2.8.3.min.js"></script>
</head>
<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->

	<div class="wrapper">
		<!--Header Area Start-->
		<header>
		    <div class="header-container">
                <!--Header Top Area Start-->
                <div class="header-top-area black-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-5">
                                <!--Header Top Left Start-->
                                <div class="header-top-left">
                                    <div class="header-top-language-currency">
                                        <div class="switcher">
                                            <div class="language">
                                                <span class="switcher-title">Language: </span>
                                                <div class="switcher-menu">
                                                    <ul>
                                                        <li><a href="#">English</a>
                                                            <ul class="switcher-dropdown">
                                                                <li><a href="#">Bangla</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="currency">
                                                <span class="switcher-title">Currency: </span>
                                                <div class="switcher-menu">
                                                    <ul>
                                                        <li><a href="#">Dollar</a>
														    <ul class="switcher-dropdown">
                                                                <li><a href="#">BDT</a></li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Header Top Left End-->
                            </div>
                            <div class="col-lg-6 col-md-7">
                                <!--Header Top Right Start-->
                                <div class="header-top-right">
                                    <ul class="menu-top-menu text-md-right">
                                        <li><a href="login-register.php">My Account</a></li>
                                        <li><a href="whishlist.php">Whishlist</a></li>
                                        <li><a href="cart.php">Shopping cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="login-register.php">Log In</a></li>
                                    </ul>
                                </div>
                                <!--Header Top Right End-->
                            </div>
                        </div>
                    </div>
                </div>
                <!--Header Top Area End-->
                <!--Header Middle Area Start-->
                <div class="header-middle-area">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-xs-12">
                                <!--Header Logo Start-->
                                <div class="header-logo">
                                    <a href="index.php"><img src="img/logo.png" alt=""></a>
                                </div>
                                <!--Header Logo End-->
                            </div>                          
                            <div class="col-xl-6 col-lg-6 col-md-7 col-xs-12 order-md-4 order-lg-3">
                                <!--Header Search Area-->
                                <div class="header-search-area">
                                    <form action="#">
                                        <div class="form-input">
                                            <input name="search" id="search" placeholder="" value="Search..." onblur="if(this.value==''){this.value='Search...'}" onfocus="if(this.value=='Search...'){this.value=''}" type="text">
                                            <button type="submit" class="header-search-btn"><i class="fa fa-search"></i></button>
                                        </div>
                                    </form>
                                </div>
                                <!--Header Search Area-->
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-2 order-md-3 order-lg-4">
                                <div class="mini-cart">
                                    <a href="#">
                                        <span class="cart-icon">
                                           <span class="cart-quantity">2</span>
                                        </span>
                                        <span class="cart-title">Your cart <br><strong>$190.00</strong></span> 
                                    </a>                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Header Middle Area End-->
                <!--Header Bottom Area Start-->
                <div class="header-bottom-area header-sticky">
                    <div class="header-boxshadow">
                        <div class="container header-inner">
                            <div class="row">
                                <div class="col-12">
                                   <!--Logo Sticky Start-->
                                   <div class="logo-sticky">
                                     <a href="index.php"><img src="img/logo.png" alt=""></a>
                                    </div>
                                   <!--Logo Sticky End-->
                                   <!--Main Menu Area Start-->
                                    <div class="header-menu text-center">
                                        <nav>
                                            <ul class="main-menu">
                                                <li><a href="index.php">Home</a> </li>                              
                                                
												<li><a href="about.php">About Us</a></li>
												 
                                                <li><a href="shop.php">Shop</a></li>                                                                                         
                                               
                                                <li><a href="contact.php">Contact Us</a></li>  
												
                                                <li><a href="login-register.php">Register</a></li> 
											</ul>
                                        </nav>
                                    </div>
                                    <!--Main Menu Area End--> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12"> 
                                    <!--Mobile Menu Area Start-->
                                    <div class="mobile-menu d-lg-none"></div>
                                    <!--Mobile Menu Area End-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Header Bottom Area End-->
		    </div>
		</header>
		<!--Header Area End-->