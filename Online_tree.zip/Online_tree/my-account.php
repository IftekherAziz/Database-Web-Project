<?php 
    $pages = 'my-account';
	include "index.php";	
?>