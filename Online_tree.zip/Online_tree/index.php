﻿<?php include "inc/header.php"; ?>

   <?php 
      if (isset($pages))
	  {
		  
		   if ($pages == 'shop')
		  {
			  include 'pages/shop.php';
		  }
		  if ($pages == 'about')
		  {
			  include 'pages/about.php';
		  }
		  if ($pages == 'contact')
		  {
			  include 'pages/contact.php';
		  } 
		  if ($pages == 'my-account')
		  {
			  include 'pages/my-account.php';
		  } 
		  if ($pages == 'log-reg')
		  {
			  include 'pages/login-register.php';
		  } 
		  if ($pages == 'checkout')
		  {
			  include 'pages/checkout.php';
		  }
		  if ($pages == 'cart')
		  {
			  include 'pages/cart.php';
		  }
		  if ($pages == 'whishlist')
		  {
			  include 'pages/whishlist.php';
		  } 
		  if ($pages == 'faq')
		  {
			  include 'pages/faq.php';
		  } 
		  if ($pages == 'single-product')
		  {
			  include 'pages/single-product.php';
		  }
		  if ($pages == 'single-blog')
		  {
			  include 'pages/single-blog.php';
		  }		  
	  }
      else
	  {
		  include 'pages/index.php';
	  }  
   ?>

<?php include "inc/footer.php";        