<?php 
    $pages = 'about';
	include "index.php";	
?>