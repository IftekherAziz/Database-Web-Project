﻿<?php 
    $pages = 'single-product';
	include "index.php";	
?>