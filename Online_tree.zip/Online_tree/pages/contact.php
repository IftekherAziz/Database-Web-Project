﻿     <!--Breadcrumb Tow Start-->
     <div class="mr-90 ml-90 mt-10">
		<div class="breadcrumb-tow">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Contact Us</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li class="active">Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
        <!--Contact Address Area Start-->
        <div class="contact-address-area pt-120 pb-80">
            <div class="container">
                <div class="row">
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-3">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Address Street</h2>
                                <p>Address :Shyamoli Road 02<br>
								 Dhaka ,Bangladesh
								</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-3">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Phone Number </h2>
                                <p>Phone 1: 01670407073 <br> Phone 2: 01823820953</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-3">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-fax"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Fax Number </h2>
                                <p>Fax 1: 0(1234) 567 89012 <br> Fax 2: 0(987) 567 890</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-3">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-envelope-o"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Email Address </h2>
                                <p>ceo@azizchy.com <br> hridoyftp@gmail.com</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                </div>
            </div>
        </div>
        <!--Contact Address Area End-->
        <!--Contact Area Start-->
        <div class="contact-area gray-bg pt-110 pl-50 pr-50 pb-50">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="contact-form-area">
                            <div class="contact-form-title">
                                <h2>Write Your Problem Here</h2>
                            </div>
                            <form id="contact-form" action="mail.php" method="post">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="contact-form-style mb-20">
                                            <input name="name" placeholder="Name*" type="text">
                                        </div>
                                    </div>                          
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="email" placeholder="Email*" type="email">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="subject" placeholder="Subject*" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="contact-form-style form-style-2">
                                            <textarea name="message" placeholder="Type your message here.."></textarea>
                                            <button class="form-button btn-style-2" type="submit"><span>Send Email</span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <p class="form-messege">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Contact Area End-->
        <!--Social Link Area Start-->
        <div class="social-link-area mb-110">
            <div class="container">
                <div class="row">

                    <div class="col-12">
						
                        <ul class="social-link">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
	</div>
    <!--Social Link Area End-->
		