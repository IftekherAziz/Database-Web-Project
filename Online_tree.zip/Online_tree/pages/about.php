﻿  	<!--Breadcrumb Tow Start-->
	<div class="mr-90 ml-90 mt-10">
		<div class="breadcrumb-tow">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>About Us</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li class="active">About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--About Us Area Start-->
		<div class="about-us-area mt-20 mb-20">
		    <div class="container-fluid p-0">
		        <div class="row no-gutters">
		            <div class="col-md-12 col-lg-6">
		                <div class="about-us-img img-full">
		                    <img src="img\about\cat-840260_1280.jpg" alt="">
		                </div>
		            </div>
		            <div class="col-md-12 col-lg-6">
		                <div class="about-us-content">
		                    <h3 class="pt-20">We Sell Trees</h3>
		                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		                     <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
						</div>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="about-us-area mt-20 mb-20">
		    <div class="container-fluid p-0">
		        <div class="row no-gutters">
		           
		            <div class="col-md-12 col-lg-6">
		                <div class="about-us-content">
		                    <h3 class="pt-20">Our History</h3>
		                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		                     <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. </p>
						</div>
		            </div>
					 <div class="col-md-12 col-lg-6">
		                <div class="pt-20 about-us-img img-full">
		                    <img src="img\about\market-1455031_1280.png" alt="">
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--About Us Area End-->
	</div>	
		