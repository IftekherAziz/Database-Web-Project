﻿   
		<!--Home Product Layout Area Start-->
		<div class="home-product-layout-area mt-40">
		    <div class="container">
		        <div class="row">
		            <div class="col-lg-3 order-lg-1 order-2">
		                <div class="sidebar-layout mb-35">
		                    <div class="category-menu">
                                <div class="category-heading">
                                    <h2 class="categories-toggle"><span>Categories</span></h2>
                                </div>
                                <div id="cate-toggle" class="category-menu-list">
                                    <ul>
                                        <li><a href="shop.php">Avenue Trees</a></li>
                                        <li><a href="shop.php">Cactus</a></li>
                                        <li><a href="shop.php">Orchid</a></li>
										<li><a href="shop.php">Trees</a></li>
                                        <li><a href="shop.php">Palm</a></li>  
										<li><a href="shop.php">Herbal</a></li>
                                        <li><a href="shop.php">Indoor Plant</a></li>
                                        <li><a href="shop.php">Organic</a></li>            
                                        <li class="rx-child"><a href="shop.php">Flowers</a></li>
                                        <li class="rx-child"><a href="shop.php">Fruits</a></li>
                                        <li class="rx-child"><a href="shop.php">Spices</a></li>       
										<li class="rx-child"><a href="shop.php">Patabahar</a></li>
                                        <li class="rx-child"><a href="shop.php">Seeds</a></li>
                                        <li class="rx-child"><a href="shop.php">Lights & Planter</a></li>
                                        <li class="rx-child"><a href="shop.php">Garden Lights</a></li>
                                        <li class="rx-parent">
                                            <a class="rx-default"><span class="cat-thumb  fa fa-plus"></span>More</a>
                                            <a class="rx-show"><span class="cat-thumb  fa fa-minus"></span>Less</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
		                </div>
		                <div class="sidebar-layout mb-35">
                            <div class="featured-product">
                                <div class="sidebar-title text-center">
                                    <h3>Featured</h3>
                                </div>
                                <div class="sidebar-product-active">
                                    <div class="product-item">
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product6.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Phasellus vel hss</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$55.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product11.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Pellentesque position</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$100.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product19.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Pellentesque furniture</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$45.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                    </div>
                                    <div class="product-item">
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product14.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Kaoreet furniture</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$95.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product23.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Phasellus vel hendrerit</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$55.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product22.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Pellentesque posuere</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$100.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                    </div>
                                    <div class="product-item">
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product16.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Auctor gravida enim</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$60.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product13.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Habitasse dictumst</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$60.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                        <!--Single List Product Start-->
                                        <div class="single-product product-list">
                                            <div class="list-col-4">
                                                <div class="product-img img-full">
                                                    <a href="single-product.php"><img src="img\product\product10.jpg" alt=""></a>
                                                </div>
                                            </div>
                                            <div class="list-col-8">
                                                <div class="product-content">
                                                    <h2><a href="single-product.php">Kaoreet lobortis</a></h2>
                                                    <div class="product-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">$95.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Single List Product Start-->
                                    </div>
                                </div>
                            </div>
		                </div>
		                <div class="sidebar-layout mb-35">
		                    <div class="sidebar-banner single-banner">
		                        <div class="banner-img">
		                            <a href="#"><img src="img/banner/shopsidebar.jpg" alt=""></a>
		                        </div>
		                    </div>
		                </div>
		                <div class="sidebar-layout">
		                    <div class="sidebar-title text-center">
		                        <h3>Popular Tags</h3>
		                    </div>
		                    <div class="product-tag">
		                        <ul>
		                            <li><a href="shop.php">Cactus</a></li>
		                            <li><a href="shop.php">Orchid</a></li>
		                            <li><a href="shop.php">Organic</a></li>
		                            <li><a href="shop.php">Spices</a></li>
		                            <li><a href="shop.php">Bonsai</a></li>
		                            <li><a href="shop.php">Flowers</a></li>
									<li><a href="shop.php">Rose</a></li>
									<li><a href="shop.php">Tulip</a></li>
		                            <li><a href="shop.php">Herbal</a></li>
		                            <li><a href="shop.php">Fruits</a></li>
		                            <li><a href="shop.php">Palm</a></li>
		                            <li><a href="shop.php">Mango</a></li>
		                        </ul>
		                    </div>
		                </div>
		            </div>
		            <div class="col-lg-9 order-lg-2 order-1">
		                <div class="product-layout">
		                    <div class="banner-area">
		                        <div class="row">
		                            <div class="col-md-6">
		                                <!--Single Banner Area Start-->
		                                <div class="single-banner mb-35">
                                            <div class="banner-img">
                                                <a href="#">
                                                    <img src="img\banner\banner6.jpg" alt="">
                                                </a>
                                            </div>
                                        </div>
		                                <!--Single Banner Area End-->
		                            </div>
		                            <div class="col-md-6">
		                                <!--Single Banner Area Start-->
		                                <div class="single-banner mb-35">
                                            <div class="banner-img">
                                                <a href="#">
                                                    <img src="img\banner\banner7.jpg" alt="">
                                                </a>
                                            </div>
                                        </div>
		                                <!--Single Banner Area End-->
		                            </div>
		                        </div>
		                    </div>
		                    <div class="store-area mt-85">
		                        <div class="row">
		                            <!--Section Title Start-->
                                    <div class="col-12">
                                        <div class="section-title text-center">
                                            <h3>Shop in Store</h3>
                                        </div>
                                    </div>
                                    <!--Section Title End-->
		                        </div>
		                        <div class="row">
		                            <div class="col-12">
		                                <!--Store Tab Menu Start-->
		                                <div class="store-product-menu">
                                            <ul class="nav justify-content-center mb-45">
                                                <li><a class="active" data-toggle="tab" href="#new">New Arrivals</a></li>
                                                <li><a data-toggle="tab" href="#top">Top Rated</a></li>
                                                <li><a data-toggle="tab" href="#onsale">On Sale</a></li>
                                            </ul>
                                        </div>
		                                <!--Store Tab Menu End-->
		                            </div>
		                            <div class="col-12">
		                                <!--Store Tab Content Start-->
		                                <div class="tab-content">
		                                    <div id="new" class="tab-pane fade show active">
		                                        <div class="row">
                                                    <div class="store-slider-active">
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product1.jpg" alt="">
                                                                    </a>
                                                                    <span class="onsale">Sale!</span>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li>
																			<a href"#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Eleifend quam</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$115.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product2.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Odio tortor consequat</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product3.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist`php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Commodo dolor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product4.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Fusce tempor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product5.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Integer eget augue</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product6.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Egestas dapibus</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product7.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Auctor sem</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product8.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sapien libero</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$82.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product9.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Pharetra sagittis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product10.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Turpis et iaculis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$65.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product11.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sit amet felis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product12.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Lacus dignissim</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                    </div>
                                                </div>
		                                    </div>
		                                    <div id="top" class="tab-pane fade">
		                                        <div class="row">
                                                    <div class="store-slider-active">
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product3.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Commodo dolor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product4.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Fusce tempor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product5.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Integer eget augue</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product6.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Egestas dapibus</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product7.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Auctor sem</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product8.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sapien libero</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$82.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product1.jpg" alt="">
                                                                    </a>
                                                                    <span class="onsale">Sale!</span>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Eleifend quam</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$115.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product2.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Odio tortor consequat</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product9.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Pharetra sagittis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product10.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Turpis et iaculis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$65.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product11.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sit amet felis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product12.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Lacus dignissim</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                    </div>
                                                </div>
		                                    </div>
		                                    <div id="onsale" class="tab-pane fade">
		                                        <div class="row">
                                                    <div class="store-slider-active">
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product5.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Integer eget augue</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product6.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Egestas dapibus</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product7.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Auctor sem</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product8.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sapien libero</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$82.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product9.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Pharetra sagittis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$100.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product10.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Turpis et iaculis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$65.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product11.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Sit amet felis</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product12.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Lacus dignissim</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product1.jpg" alt="">
                                                                    </a>
                                                                    <span class="onsale">Sale!</span>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Eleifend quam</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$115.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product2.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Odio tortor consequat</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$90.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product3.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Commodo dolor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$80.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                            <!--Single Product Start-->
                                                            <div class="single-product mb-25">
                                                                <div class="product-img img-full">
                                                                    <a href="single-product.php">
                                                                        <img src="img\product\product4.jpg" alt="">
                                                                    </a>
                                                                    <div class="product-action">
                                                                        <ul>
                                                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                                            <li><a href="whishlist.php" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2><a href="single-product.php">Fusce tempor</a></h2>
                                                                    <div class="product-price">
                                                                        <div class="price-box">
                                                                            <span class="regular-price">$55.00</span>
                                                                        </div>
                                                                        <div class="add-to-cart">
                                                                            <a href="cart.php">Add To Cart</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--Single Product End-->
                                                        </div>
                                                    </div>
                                                </div>
		                                    </div>
		                                </div>
		                                <!--Store Tab Content End-->
		                            </div>
		                        </div>
		                    </div>
		                    <div class="best-product mt-50">
		                        <div class="row">
                                    <!--Section Title Start-->
                                    <div class="col-12">
                                        <div class="section-title text-center mb-35">
                                            <span>Recent Trees</span>
                                            <h3>The Best Collection</h3>
                                        </div>
                                    </div>
                                    <!--Section Title End-->
                                </div>
                                <div class="row">
                                    <div class="product-list-slider-active2">
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product14.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Aliquam lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$125.00</span>
                                                                    <span class="regular-price">$115.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product16.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Auctor gravida enim</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$85.00</span>
                                                                    <span class="regular-price">$60.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product5.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Aliquam lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$80.00</span>
                                                                    <span class="regular-price">$50.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product15.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Kaoreet lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$95.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product8.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Dignissim venenatis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$80.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product22.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Dignissim furniture</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$125.00</span>
                                                                    <span class="regular-price">$115.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product23.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Phasellus vel hendrerit</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$55.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product20.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Ornare sed consequat</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$499.00</span>
                                                                    <span class="regular-price">$515.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product19.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Pellentesque posuere</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$120.00</span>
                                                                    <span class="regular-price">$100.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product18.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Aliquam lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$90.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product17.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Dignissim venenatis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$80.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product11.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Auctor gravida enim</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$85.00</span>
                                                                    <span class="regular-price">$60.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                        <div class="col-md-4">
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product2.jpg" alt=""></a>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Kaoreet lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="price">$125.00</span>
                                                                    <span class="regular-price">$120.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                            <!--Single List Product Start-->
                                            <div class="single-product product-list mb-35">
                                                    <div class="list-col-4">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.php"><img src="img\product\product4.jpg" alt=""></a>
                                                            <span class="onsale">Sale!</span>
                                                            <div class="product-action">
                                                                <ul>
                                                                    <li><a href="#open-modal" data-toggle="modal" title="Quick view" tabindex="0"><i class="fa fa-search"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="#" tabindex="0"><i class="fa fa-refresh"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="list-col-8">
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php">Kaoreet lobortis</a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">$45.00</span>
                                                                </div>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="cart.php" tabindex="0">Add To Cart</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--Single List Product Start-->
                                        </div>
                                    </div>
                                </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Home Product Layout Area End-->		
		<!--Feature Area Start-->
		<div class="feature-area mt-30">
		    <div class="container">
		        <div class="row">
		            <div class="col-lg-4 col-md-6">
		                <!--Single Feature Start-->
		                <div class="single-feature mb-35">
		                    <div class="feature-icon">
		                        <span class="lnr lnr-rocket"></span>
		                    </div>
		                    <div class="feature-content">
		                        <h3>FREE DELIVERY</h3>
		                        <p>ALL ORDER OVER $100</p>
		                    </div>
		                </div>
		                <!--Single Feature End-->
		            </div>
		            <div class="col-lg-4 col-md-6">
		                <!--Single Feature Start-->
		                <div class="single-feature mb-35">
		                    <div class="feature-icon">
		                        <span class="lnr lnr-phone"></span>
		                    </div>
		                    <div class="feature-content">
		                        <h3>24/7 DEDICATED SUPPORT</h3>
		                        <p>01670 407 073</p>
								
		                    </div>
		                </div>
		                <!--Single Feature End-->
		            </div>
		            <div class="col-lg-4 col-md-6">
		                <!--Single Feature Start-->
		                <div class="single-feature mb-35">
		                    <div class="feature-icon">
		                        <span class="lnr lnr-redo"></span>
		                    </div>
		                    <div class="feature-content">
		                        <h3>EXCHANGE OPTION</h3>
		                        <p>01823 820 953</p>
		                    </div>
		                </div>
		                <!--Single Feature End-->
		            </div>
		        </div>
		    </div>
		</div> 
		<!--Feature Area End-->
		<!--News Letter Area Start-->
		<div style="background:gray;" class="news-letter-area mt-20 mb-50 mr-70 ml-70 pt-90 pb-90">
		    <div class="container">		        
		        <div class="row">
		            <div class="col-md-12">
		                <div class="news-latter-box">
		                    <div class="news-letter-form text-center">
		                        <form action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="popup-subscribe-form validate" target="_blank" novalidate="">
                                   <div id="mc_embed_signup_scroll">
                                      <div id="mc-form" class="mc-form subscribe-form">
                                        <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email here">
                                        <button id="mc-submit">Subscribe </i></button>
                                      </div>
                                   </div>
                               </form>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--News Letter Area End-->
	