﻿<?php 
    $userobj = new user();
	if(isset($_POST['register'])){		
		$message = $userobj->register_user($_POST);
	}
	if(isset($_POST['login'])){		
		$message = $userobj->check_login($_POST);
		
		
	}	
?>
	<!--Breadcrumb Tow Start-->
	<div class="mr-90 ml-90 mt-10">
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Login - Register</h1>							
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li class="active">Login-Register</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2>Login</h2>
		                    </div>
		                    <div class="login-form pt-20 pb-10">
		                        <form action="" method="post">
		                            <div class="form-fild">
		                                <p><label>Email address <span class="required">*</span></label></p>
		                                <input name="email" value="" type="email">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>Password <span class="required">*</span></label></p>
		                                <input name="password" value="" type="password">
		                            </div>
		                            <div class="login-submit">
		                                <input type="submit" name='login' value="Login" class="form-button" />	                               
		                            </div>
		                            <div class="lost-password">
		                                <a href="#">Lost your password?</a>
		                            </div>
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            <!--Register Form Start-->
		            <div class="col-md-6 col-sm-6">					
		                <div class="customer-login-register register-pt-0">
		                    <div class="form-register-title">
		                        <h2>Register</h2>
		                    </div>
		                    <div class="register-form">
		                        <form action="" method="post">
		                            <div class="form-fild">
		                                <p><label>Email address <span class="required">*</span></label></p>
		                                <input name="email" value="" type="email">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>Password <span class="required">*</span></label></p>
		                                <input name="password" value="" type="password">
		                            </div>
		                            <div class="register-submit">
		                              
										<input type="submit" name="register" value="Register"  class="form-button"/>
		                            </div>
		                        </form>
		                    </div>							
		                </div>
		            </div>
		            <!--Register Form End-->
		        </div> 
				<p style="text-align:center;"> <?php if(isset($message)){echo $message;}?> </p>
		    </div>
		</div>
		
	</div>
	<!--Login Register Area End-->
		