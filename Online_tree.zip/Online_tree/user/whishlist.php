﻿<?php 
    $pages = 'whishlist';
	include "index.php";	
?>