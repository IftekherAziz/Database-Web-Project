﻿<?php 
    $pages = 'faq';
	include "index.php";	
?>