﻿<?php 
    $pages = 'log-reg';
	include "index.php";	
?>